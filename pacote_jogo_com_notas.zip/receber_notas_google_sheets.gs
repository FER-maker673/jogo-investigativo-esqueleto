/**
 * OPERAÇÃO OSSOS SOB INVESTIGAÇÃO
 * Recebe as notas dos alunos e registra cada tentativa na planilha vinculada.
 *
 * COMO USAR:
 * 1. Crie uma planilha Google.
 * 2. Abra Extensões > Apps Script.
 * 3. Apague o conteúdo inicial e cole este código.
 * 4. Salve e implante como Aplicativo da Web.
 */
function doPost(e) {
  try {
    var dados = JSON.parse(e.postData.contents);
    var planilha = SpreadsheetApp.getActiveSpreadsheet();
    var aba = planilha.getSheetByName("Resultados");

    if (!aba) {
      aba = planilha.insertSheet("Resultados");
      aba.appendRow([
        "Data/hora do envio", "Nome do aluno", "Turma",
        "Acertos", "Total de questões", "Nota (0 a 10)",
        "Percentual", "Detalhes das respostas"
      ]);
      aba.setFrozenRows(1);
    }

    var respostas = (dados.respostas || []).map(function(r) {
      return "Q" + r.questao + ": marcada " + r.respostaMarcada +
        " | correta " + r.respostaCorreta +
        " | " + (r.correta ? "acerto" : "erro");
    }).join(" ; ");

    aba.appendRow([
      new Date(),
      dados.nome || "",
      dados.turma || "",
      Number(dados.pontos || 0),
      Number(dados.total || 10),
      Number(dados.nota || 0),
      Number(dados.percentual || 0) + "%",
      respostas
    ]);

    return ContentService
      .createTextOutput(JSON.stringify({ ok: true }))
      .setMimeType(ContentService.MimeType.JSON);
  } catch (erro) {
    return ContentService
      .createTextOutput(JSON.stringify({ ok: false, erro: String(erro) }))
      .setMimeType(ContentService.MimeType.JSON);
  }
}
